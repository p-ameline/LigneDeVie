package com.ldv.client.canvas;

public class LdvRosace {

	public LdvRosace(){

	}
	
}
