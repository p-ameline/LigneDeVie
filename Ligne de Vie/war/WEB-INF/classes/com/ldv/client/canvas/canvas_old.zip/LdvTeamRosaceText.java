package com.ldv.client.canvas;

import com.swtb.font.client.Simplex;

public class LdvTeamRosaceText extends LdvTeamRosaceObject
{
	private LdvCoordinatesCartesian _centerPoint = new LdvCoordinatesCartesian(0.0d, 0.0d) ;
	
	private double    _dRadius ;
	private double    _dLeftAngleCanvasR ;
	private double    _dRightAngleCanvasR ;
	private String    _sText ;
	
	private final int _iSpace = 30 ;
	private double    _dAngleCanvasR ;       // Global angle range for text
	private double    _dAngleLetterCanvasR ; // It is supposed that all letters use the same angle range
	
	public LdvTeamRosaceText(LdvTeamRosaceCanvas canvas, double dCenterX, double dCenterY, double dRadius, double dLeftAngleCanvasR, double dRightAngleCanvasR, String sText)
	{
		super(canvas, "text") ;
		
		_centerPoint.setX(dCenterX) ;
		_centerPoint.setY(dCenterY) ;
		
		_dRadius             = dRadius + _iSpace ;
		_dLeftAngleCanvasR   = dLeftAngleCanvasR ;
		_dRightAngleCanvasR  = dRightAngleCanvasR ;
		_sText               = sText ;
		_dAngleCanvasR       = dLeftAngleCanvasR - dRightAngleCanvasR ;
		_dAngleLetterCanvasR = _dAngleCanvasR / (sText.length()) ;
	}
	
	@Override
	public boolean contains(double x, double y) {
		return false ;
	}

	@Override
	public void draw() 
	{
		LdvCoordinatesPolar currentPoint = new LdvCoordinatesPolar(_dLeftAngleCanvasR, _dRadius) ;
		
		for (int i = 0 ; i <= _sText.length() - 1 ; i++)
		{
			String sLetter = String.valueOf(_sText.charAt(i)) ;
			double dCurrentAngleCanvasR = _dLeftAngleCanvasR - i * _dAngleLetterCanvasR ;
			
			// currentPoint.setCoordinates(getCanvasRAngleFromLdvDAngle(dCurrentAngleR), _dRadius) ;
			currentPoint.setCoordinates(dCurrentAngleCanvasR, _dRadius) ;
			
			LdvCoordinatesCartesian current = new LdvCoordinatesCartesian(currentPoint, _centerPoint) ;
			
			// Angle of the letter 
			//
			double angleLean = - Math.PI/2 + dCurrentAngleCanvasR ;
			 
			Simplex simplex = new Simplex() ;
			_Canvas.setFont(simplex) ;
			 
			_Canvas.saveContext() ;
			//canvas.setItalic(true) ;
			_Canvas.setLineWidth(1.25) ;
			_Canvas.beginPath() ;
			_Canvas.textTo(sLetter, current.getX(), current.getY(), angleLean, 0.8) ;
			_Canvas.stroke() ;
			_Canvas.restoreContext() ;       
		}
	}

	@Override
	public int getHeight() {
		return 0;
	}

	@Override
	public String getName() {
		return _sName ;
	}

	@Override
	public double getLeftAngleCanvasR() {
		return _dLeftAngleCanvasR ;
	}

	@Override
	public double getRadius() {
		return 0.0d ;
	}

	@Override
	public double getRightAngleCanvasR() {
		return _dRightAngleCanvasR ;
	}	
}
