package com.ldv.client.canvas;

import java.util.ArrayList;
import java.util.Iterator;

/** 
 * A LdvTeamRosaceStructure represents an angular sector, a given category team members (whatever their distance)
 * 
 */
public class LdvTeamRosaceStructure 
{
	private int    _iRosaceAngleLdvD ;
	
	private String _sLabel ;
	
	private int    _iRadiusMin ;
	private int    _iRadiusMax ;
	
	private ArrayList<LdvTeamRosacePetalDescriptor> _vPetals ;
	
	public LdvTeamRosaceStructure(int iRosaceAngleLdvD, String label, int radiusMin, int radiusMax)
	{	
		_iRosaceAngleLdvD = iRosaceAngleLdvD ;
		_sLabel           = label ;
		_iRadiusMin       = radiusMin ;
		_iRadiusMax       = radiusMax ;				
		_vPetals          = new ArrayList<LdvTeamRosacePetalDescriptor>() ;
	}

	public boolean isCenter() {
		return (0 == _iRadiusMin) && (0 == _iRadiusMax) ;
	}
	
	public int getRosaceAngleLdvD() {
		return _iRosaceAngleLdvD ;
	}
	public void setRosaceAngleLdvD(int angle) {
		_iRosaceAngleLdvD = angle ;
	}
	
	public String getLabel() {
		return _sLabel ;
	}
	public void setLabel(String label) {
		_sLabel = label ;
	}

	public int getRadiusMin() {
		return _iRadiusMin ;
	}
	public void setRadiusMin(int radiusMin) {
		_iRadiusMin = radiusMin ;
	}

	public int getRadiusMax() {
		return _iRadiusMax ;
	}
	public void setRadiusMax(int radiusMax) {
		_iRadiusMax = radiusMax ;
	}
	
	public LdvTeamRosacePetalDescriptor getPetalDescriptor(int iRadius)
	{
		if (_vPetals.isEmpty())
			return null ;
		
		Iterator<LdvTeamRosacePetalDescriptor> it = _vPetals.iterator() ;
		while(it.hasNext())
		{
			LdvTeamRosacePetalDescriptor currentPetal = it.next() ;
			if (currentPetal.getRadius() == iRadius)
				return currentPetal ;
		}
		
		return null ;
	}
	
	public ArrayList<LdvTeamRosacePetalDescriptor> getPetals() {
		return _vPetals ;
	}	
}
